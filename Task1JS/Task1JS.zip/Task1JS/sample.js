function hello(){
    var fname=document.getElementById("fname").value;
    if(fname=="")
    document.getElementById("demo").innerHTML="Name is null";
}